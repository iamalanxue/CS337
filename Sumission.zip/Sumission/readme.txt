In a new enviroment,run:
python3 install -r requirements.txt


Make sure to download packages for nltk.

To use the project, run:
python3 gg_api.py year

year is either 2013 or 2015.
For example:
python3 gg_api.py 2013


Each function stub (e.g., get_hosts(), get_awards()) accepts a string of year as input.